﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CW2.Server.Data.Migrations
{
    public partial class Seeding1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
